package com.niit.Iphonebackend;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.Iphonebackend.dao.SupplierDAO;
import com.niit.Iphonebackend.model.Supplier;

public class SupplierTest {
	
	
	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.Iphonebackend");
		context.refresh();
		
		
	   SupplierDAO supplierDAO = 	(SupplierDAO) context.getBean("supplierDAO");
	   
	   Supplier supplier = 	(Supplier) context.getBean("supplier");
	   supplier.setId("CG20");
	   supplier.setName("CGName120");
	   supplier.setAddress("vishakapatnam");
	   
	   
	   supplierDAO.saveOrUpdate(supplier);
	   
	   
	   
	   
	  
		
	}

}
