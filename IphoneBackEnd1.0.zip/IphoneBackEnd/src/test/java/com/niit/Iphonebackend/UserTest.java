package com.niit.Iphonebackend;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.Iphonebackend.dao.UserDAO;
import com.niit.Iphonebackend.model.User;

public class UserTest {

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.niit.Iphonebackend");
		context.refresh();

		UserDAO userDAO = (UserDAO) context.getBean("UserDAO");

		User user = (User) context.getBean("user");
		user.setId("US121");
		user.setName("USName120");
		user.setAddress("hyderabad");
		user.setMail("xyz@example.com");
		user.setMobile(999999998);
		user.setPassword("password");

		userDAO.saveOrUpdate(user);

		
	}

}

