package com.niit.Iphonebackend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.Iphonebackend.dao.CategoryDAO;
import com.niit.Iphonebackend.model.Category;

public class CategoryTest {
	
	
	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.Iphonebackend");
		context.refresh();
		
		
	   CategoryDAO categoryDAO = 	(CategoryDAO) context.getBean("categoryDAO");
	   
	   Category category = 	(Category) context.getBean("category");
	   category.setId("CG128");
	   category.setName("CGName120");
	   category.setDescription("CGDesc120");
	   
	   
	   categoryDAO.saveOrUpdate(category);
	   
	   
	   
	
		
		
		
	}

}
