package com.niit.Iphonebackend;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.Iphonebackend.dao.ProductDAO;
import com.niit.Iphonebackend.model.Product;

public class ProductTest {
	
	
	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.Iphonebackend");
		context.refresh();
		
		
	   ProductDAO productDAO = 	(ProductDAO) context.getBean("productDAO");
	   
	   Product product = 	(Product) context.getBean("product");
	   product.setId("PD120");
	   product.setName("PDName120");
	   product.setPrice(300);
	   product.setDescription("PDDesc120");
	   
	   
	   productDAO.saveOrUpdate(product);
	   
	   
	   
	   
	
		
		
		
	}

}
